# 고정 카메라 Eye-to-Hand 보정 오프라인 수치 해석 보고서 (`cal-2026-11-07-handeye-01`)

- **상태 (Status)**: **후보값 산출 완료 / 현장 물리 정확도 미검증 (`verify.pass = false`, `G1_pass = false`)**
- **해석 모델 (Model)**: Antigravity (Google DeepMind), 쿼터·모델 오류 없음 (`None`)
- **해석 스크립트**: `result/analysis/run_offline_handeye_analysis.py` (SHA-256: `f83e9bc03d1d6e12dd3a64f51142b1fff18de6e18ace1e4c383022f1533df048`)
- **데이터 무결성**: `fit-data-manifest.sha256` (240/240) 및 `all-data-manifest.sha256` (400/400) 해시 100% 일치 확인.

---

## 1. 좌표계 및 단위 규약 (Frame & Unit Conventions)

방정식 $B_i X = Y C_i$ (모든 $4\times 4$ 동차행렬은 열벡터 $p_{\text{parent}} = R p_{\text{child}} + t$ 변환, 길이 단위 $\text{m}$, 각도 $\text{rad}$):
- **$B_i$ (`base_link <- controller_tcp`)**: `pose-NN-posx.txt`의 실제 측정 $XYZ\text{ [mm]}$를 $\text{m}$로 변환하고, `pose-NN-rotm.txt`의 실제 $3\times 3$ 회전행렬을 $SO(3)$ 투영(최대 프로베니우스 오차 $1.267\times 10^{-6}$). 제어기 보고 TCP 이름은 빈 문자열(`""`, 제어기 기본 플랜지/TCP)이며 임의의 `tool0` TF를 가정하지 않음.
- **$X$ (`controller_tcp <- aruco_marker_25`)**: 제어기 기본 TCP에서 그리퍼에 부착된 ArUco ID 25($40\text{ mm}$, `DICT_4X4_50`) 표식 좌표계로의 강체 변환.
- **$Y$ (`base_link <- camera_color_optical_frame`)**: 로봇 베이스에서 카메라 컬러 광학 프레임으로의 고정 변환. 내부 파라미터 $K, \text{dist}$는 `src/calibration/config/d455_color_1280x800.yaml` 고정.
- **$C_i$ (`camera_color_optical_frame <- aruco_marker_25`)**: 단일 자세 PnP 측정치(`measured_single_pose_pnp`, 초기화 전용)와 최종 상수 $(X, Y)$ 모델 예측치 $C_{\text{pred},i} = Y^{-1} B_i X$ (`model_prediction`)를 분리 기록.

---

## 2. 영상 코너 검출 품질 및 무잡음 합성 검증 (Detection QC & Synthetic Check)

1. **ID 25 검출 및 버스트 지터 (`50자세 × 5장 = 250장`)**:
   - **검출률**: **250 / 250장 (100%, 누락 0장)** (`cv2.cornerSubPix` $3\times 3$ 윈도우 정밀화 적용, 표식 변 길이 평균 $\approx 50.8\text{ px}$).
   - **동일 자세 5장 버스트 내 지터**: 자세별 코너 RMS 지터 평균 **$0.0875\text{ px}$** ($p_{95} = 0.203\text{ px}$), 전체 최대 코너 변위 **$0.809\text{ px}$** (`pose-21`).
   - **고정 표식(ID 23) 카메라 부동성 QC**: 37장 기준 $p_{95} = 0.106\text{ px}$, 최대 **$0.151\text{ px}$**.
2. **무잡음 합성 검증 (실제 FIT 30자세 궤적 사용)**:
   - `cv2.calibrateHandEye(PARK)`: $Y$ 회전 오차 $1.71\times 10^{-6\circ}$, 병진 오차 $1.18\times 10^{-12}\text{ mm}$.
   - 분리형 선형 최소제곱(`Decoupled LS`) 및 픽셀 번들 정밀화(`LM`): $Y$ 병진 오차 **$1.48\times 10^{-13}\text{ mm}$**, $X$ 병진 오차 **$1.43\times 10^{-14}\text{ mm}$**, 재투영 RMS **$8.61\times 10^{-13}\text{ px}$**.

---

## 3. FIT 전용 추정 방법 비교 및 HOLDOUT 평가 (`FIT = pose-00..29`, `HOLDOUT = pose-30..49`)

모든 모델 학습·초기화 비교·번들 정밀화는 **오직 FIT (`pose-00..29`, 30자세, 120코너)** 만 사용했으며, **HOLDOUT (`pose-30..49`, 20자세, 80코너)** 은 최종 고정된 $(X, Y)$로 단 1회 평가함.

| 초기화 방법 (`cv2.calibrateHandEye`) | 단계 1: 순수 `calibrateHandEye` FIT RMS [px] | 단계 2: `R_C` 제거 분리형 병진 LS FIT RMS [px] | 단계 3: 왜곡 반영 픽셀 번들 정밀화 FIT RMS / p95 / max [px] | 단계 3: 픽셀 번들 정밀화 **HOLDOUT** RMS / p95 / max [px] |
| :--- | :---: | :---: | :---: | :---: |
| `TSAI` | 3.450 | 1.771 | **0.977** / 1.694 / 2.223 | **1.147** / 1.925 / 2.324 |
| **`PARK` (선정)** | 3.650 | 1.326 | **0.977** / 1.694 / 2.223 | **1.147** / 1.925 / 2.324 |
| `HORAUD` | 3.650 | 1.326 | **0.977** / 1.694 / 2.223 | **1.147** / 1.925 / 2.324 |
| `ANDREFF` | 128.051 | 1.310 | **0.977** / 1.694 / 2.223 | **1.147** / 1.925 / 2.324 |
| `DANIILIDIS` | 2.040 | 1.311 | **0.977** / 1.694 / 2.223 | **1.147** / 1.925 / 2.324 |

- 5개 초기화(`TSAI`, `PARK`, `HORAUD`, `ANDREFF`, `DANIILIDIS`) 모두 픽셀 번들 정밀화 후 **동일한 전역 최적해**(병진 차이 $< 10^{-6}\text{ mm}$)로 수렴함.
- 카메라 광학축 기준 모든 50자세의 표식 깊이 $Z_{\text{cam}} \in [0.3896\text{ m}, 0.5698\text{ m}]$ 로 양수($+Z$) 조건 및 정상 회전행렬($\det(R)=+1$) 만족.

---

## 4. 최종 후보 변환행렬 및 불확도 (Estimated Candidate Transforms & Conditioning)

### 4.1 $Y$: `base_link <- camera_color_optical_frame` (`camera_extrinsics_candidate.yaml`)
- **병진 `translation_m`**: `[0.84658274, 0.05628051, 0.59247576]` m (`[846.583, 56.281, 592.476]` mm; 사용자 보고 테이블 위 공칭 높이 ~600 mm와 부합하나 베이스 좌표계 실측 GT는 아님)
- **회전 `rotation_xyzw`**: `[0.71270585, 0.70138111, 0.00987464, 0.0041724]`
- **행렬 $Y$ ($4\times 4$)**:
```json
[
  [
    0.01593407,
    0.99967443,
    0.0199283,
    0.84658274
  ],
  [
    0.99983923,
    -0.01609426,
    0.00790438,
    0.05628051
  ],
  [
    0.00822254,
    0.01979915,
    -0.99977017,
    0.59247576
  ],
  [
    0.0,
    0.0,
    0.0,
    1.0
  ]
]
```
- **역행렬 $Y^{-1}$ (`camera_color_optical_frame <- base_link`)**:
  - `translation_m`: `[-0.07463262, -0.85713184, 0.57502377]` m
  - `rotation_xyzw`: `[-0.71270585, -0.70138111, -0.00987464, 0.0041724]`

### 4.2 $X$: `controller_tcp <- aruco_marker_25` (`marker_offset_candidate.yaml`)
- **병진 `translation_m`**: `[-0.00024538, -0.03951986, 0.14718508]` m (`[-0.245, -39.52, 147.185]` mm)
- **회전 `rotation_xyzw`**: `[0.70409947, -0.70964169, -0.02544088, 0.00231933]`
- **행렬 $X$ ($4\times 4$)**:
```json
[
  [
    -0.00847712,
    -0.99919866,
    -0.03911759,
    -0.00024538
  ],
  [
    -0.99943468,
    0.0071934,
    0.03284174,
    -0.03951986
  ],
  [
    -0.03253403,
    0.03937388,
    -0.99869477,
    0.14718508
  ],
  [
    0.0,
    0.0,
    0.0,
    1.0
  ]
]
```
- **역행렬 $X^{-1}$ (`aruco_marker_25 <- controller_tcp`)**:
  - `translation_m`: `[-0.03471107, -0.00575615, 0.14828127]` m
  - `rotation_xyzw`: `[-0.70409947, 0.70964169, 0.02544088, 0.00231933]`

### 4.3 조건수 및 1-$\sigma$ 파라미터 공분산 (FIT 자코비안 기준, $\text{DOF} = 228$)
- 분리형 병진 시스템 $[R_{B,i}, -I_3]$ 조건수: **$\kappa = 5.53$** (특이값 `[7.622, 7.569, 7.52, 1.859, 1.648, 1.378]`).
- 번들 정밀화 자코비안 조건수: **$\kappa(J) = 230.42$**.
- 번들 정밀화 $1\sigma$ 표준오차 (표식 크기 $40\text{ mm}$ 및 $K$가 완벽히 참이라고 가정할 때의 내부 통계적 하한):
  - $Y$ 회전 $1\sigma$ (deg): `[0.1099, 0.0776, 0.1563]`
  - $Y$ 병진 $1\sigma$ (mm): `[0.871, 0.784, 0.58]`
  - $X$ 회전 $1\sigma$ (deg): `[0.2351, 0.1694, 0.357]`
  - $X$ 병진 $1\sigma$ (mm): `[0.197, 0.172, 0.252]`

---

## 5. 물리 검증 미비 사유 및 배포 불가 판정 (Why Physical Validation is Required)

1. **독립 TCP 접촉 검증 부재 (`independent_touch_points_count = 0`, `G1_pass = false`)**:
   - 현재 결과는 그리퍼에 고정된 단일 표식의 영상 투영 루프($Y^{-1} B_i X P_{\text{marker}}$)만 맞춘 후보값이다.
2. **픽셀 재투영 오차(HOLDOUT 1.147 px)가 1 mm 로봇 물리 정확도를 보증하지 못하는 이유**:
   - 표식 실측 크기($40\text{ mm}$)의 미세 오차, 카메라 내부 파라미터 잔여 왜곡, 그리고 $X$와 $Y$ 사이의 잔여 공선 오차는 폐루프 $Y^{-1} B_i X$ 내부에서 서로 상쇄되어 픽셀 잔차에 드러나지 않는다.
   - 따라서 `camera_extrinsics_candidate.yaml`의 `residuals.verify.pass = false`를 유지하며, 실제 컨베이어 작업 평면 위에서 보정된 TCP 끝단으로 최소 $n \ge 20$개 독립 접촉점(`TC-BEN-012-01`: XY $p_{95} \le 1.0\text{ mm}$, 최대 $\le 2.0\text{ mm}$)을 측정하기 전까지 운영 설정에 배포해서는 안 된다.
